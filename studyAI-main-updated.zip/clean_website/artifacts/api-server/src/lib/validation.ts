import type { Response } from "express";

// Single source of truth for the "material is too short" rule across every
// route that either ingests material text or generates content from it
// (upload, summaries, questions/quiz, flashcards, exams, generate-all).
export const MIN_CONTENT_LENGTH = 500;

// Below this length, material is technically valid (>= MIN_CONTENT_LENGTH)
// but still thin. Asking Groq for a full 10-question/15-card set out of
// ~500-799 characters reliably produces duplicates, padding, or empty
// arrays. We cap the requested counts instead.
export const SHORT_CONTENT_THRESHOLD = 800;

export const INSUFFICIENT_CONTENT_ERROR = "insufficient_content";

export function insufficientContentMessage(language: "he" | "en" = "he") {
  return language === "en"
    ? `This material is too short to generate accurate content. Please provide at least ${MIN_CONTENT_LENGTH} characters of text.`
    : `החומר קצר מדי כדי לייצר ממנו תוכן מדויק. אנא הוסיפו טקסט של לפחות ${MIN_CONTENT_LENGTH} תווים.`;
}

/**
 * Returns true (and writes a 400 JSON response) if `text` is shorter than
 * MIN_CONTENT_LENGTH. Callers should `return` immediately when this returns
 * true, since the response has already been sent.
 */
export function rejectIfTooShort(
  res: Response,
  text: string | null | undefined,
  language: "he" | "en" = "he"
): boolean {
  const length = (text || "").trim().length;
  if (length < MIN_CONTENT_LENGTH) {
    res.status(400).json({
      error: INSUFFICIENT_CONTENT_ERROR,
      message: insufficientContentMessage(language),
      minLength: MIN_CONTENT_LENGTH,
      receivedLength: length,
    });
    return true;
  }
  return false;
}

/**
 * Caps the number of flashcards/questions we ask Groq to generate when the
 * source material is short (>= MIN_CONTENT_LENGTH but < SHORT_CONTENT_THRESHOLD).
 * Used by every generation route (single-item and generate-all) so the rule
 * is identical everywhere instead of being re-implemented per route.
 */
export function getDynamicGenerationLimits(contentLength: number) {
  const isShort = contentLength < SHORT_CONTENT_THRESHOLD;
  return {
    isShort,
    maxQuestions: isShort ? 5 : 10,
    maxFlashcards: isShort ? 6 : 15,
  };
}

/** Clamp a user/client-requested count down to what's safe for this content length. */
export function clampToContentLength(requestedCount: number, contentLength: number, kind: "questions" | "flashcards"): number {
  const { maxQuestions, maxFlashcards } = getDynamicGenerationLimits(contentLength);
  const cap = kind === "questions" ? maxQuestions : maxFlashcards;
  return Math.min(requestedCount, cap);
}
