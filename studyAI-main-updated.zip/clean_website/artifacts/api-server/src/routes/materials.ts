import { Router } from "express";
import multer from "multer";
import { db, materialsTable, summariesTable, flashcardDecksTable, flashcardsTable, questionSetsTable, questionsTable, examsTable, activityTable } from "@workspace/db";
import { eq, count, and } from "drizzle-orm";
import { CreateMaterialBody, ListMaterialsQueryParams, GetMaterialParams, DeleteMaterialParams } from "@workspace/api-zod";
import { extractYouTube, extractPDF, transcribeAudio, extractFromUrl } from "../lib/extractor";
import { rejectIfTooShort } from "../lib/validation";

const router = Router();

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 25 * 1024 * 1024 },
});

async function getMaterialWithCounts(id: number, userId: number) {
  const [material] = await db.select().from(materialsTable)
    .where(and(eq(materialsTable.id, id), eq(materialsTable.userId, userId)));
  if (!material) return null;

  const [summaryCount] = await db.select({ value: count() }).from(summariesTable).where(eq(summariesTable.materialId, id));
  const [deckCount] = await db.select({ value: count() }).from(flashcardDecksTable).where(eq(flashcardDecksTable.materialId, id));
  const [qSetCount] = await db.select({ value: count() }).from(questionSetsTable).where(eq(questionSetsTable.materialId, id));
  const [examCount] = await db.select({ value: count() }).from(examsTable).where(eq(examsTable.materialId, id));

  const [flashcardCountRow] = await db.select({ value: count() }).from(flashcardsTable)
    .innerJoin(flashcardDecksTable, eq(flashcardsTable.deckId, flashcardDecksTable.id))
    .where(eq(flashcardDecksTable.materialId, id));

  const [questionCountRow] = await db.select({ value: count() }).from(questionsTable)
    .innerJoin(questionSetsTable, eq(questionsTable.setId, questionSetsTable.id))
    .where(eq(questionSetsTable.materialId, id));

  return {
    ...material,
    summaryCount: Number(summaryCount.value),
    flashcardCount: Number(flashcardCountRow?.value || 0),
    questionCount: Number(questionCountRow?.value || 0),
    examCount: Number(examCount.value),
    deckCount: Number(deckCount.value),
    qSetCount: Number(qSetCount.value),
  };
}

router.get("/materials", async (req, res) => {
  const userId = req.user!.userId;
  const query = ListMaterialsQueryParams.parse({ courseId: req.query.courseId ? Number(req.query.courseId) : undefined });

  const rows = query.courseId
    ? await db.select().from(materialsTable)
        .where(and(eq(materialsTable.userId, userId), eq(materialsTable.courseId, query.courseId)))
        .orderBy(materialsTable.createdAt)
    : await db.select().from(materialsTable)
        .where(eq(materialsTable.userId, userId))
        .orderBy(materialsTable.createdAt);

  const withCounts = await Promise.all(rows.map(m => getMaterialWithCounts(m.id, userId)));
  res.json(withCounts.filter(Boolean));
});

router.post("/materials", upload.single("file"), async (req, res) => {
  const userId = req.user!.userId;

  let body: any;
  if (req.file) {
    body = req.body;
  } else {
    try {
      body = CreateMaterialBody.parse(req.body);
    } catch {
      return res.status(400).json({ error: "Invalid request body" });
    }
  }

  const title = body.title || "Untitled Material";
  const contentType = body.contentType || "text";
  const language = body.language || "he";
  const courseId = body.courseId ? Number(body.courseId) : undefined;
  const sourceUrl = body.sourceUrl || undefined;

  // For plain pasted/typed text there is no extraction step, so the raw
  // input IS the content that would be used for generation later. Reject
  // it here, before we ever write a row, instead of silently saving a
  // too-short material that will only fail later when the user tries to
  // generate a summary or quiz from it.
  if (contentType === "text" && rejectIfTooShort(res, body.text, language === "en" ? "en" : "he")) {
    return;
  }

  let extractedText = body.text || "";
  let duration: number | undefined;
  let processingError: string | undefined;

  try {
    if (contentType === "youtube" && sourceUrl) {
      const result = await extractYouTube(sourceUrl);
      extractedText = result.text;
      duration = result.duration;
    } else if (contentType === "url" && sourceUrl) {
      const result = await extractFromUrl(sourceUrl);
      extractedText = result.text;
    } else if (contentType === "pdf" && req.file) {
      const result = await extractPDF(req.file.buffer);
      extractedText = result.text;
    } else if ((contentType === "audio" || contentType === "video") && req.file) {
      const result = await transcribeAudio(
        req.file.buffer,
        req.file.mimetype,
        req.file.originalname
      );
      extractedText = result.text;
      duration = result.duration;
    } else if (!extractedText && sourceUrl) {
      extractedText = sourceUrl;
    }
  } catch (err: any) {
    req.log.error({ err }, "Content extraction failed");
    processingError = err.message || "Extraction failed";
    extractedText = sourceUrl || body.text || `[Extraction failed: ${processingError}]`;
  }

  const status = processingError ? "error" : "ready";

  // For content types that go through extraction (PDF, audio/video,
  // YouTube, URL), the raw input (a file or a link) isn't a meaningful
  // length to validate — only the text that came OUT of extraction is.
  // Skip this check if extraction already failed; that error takes priority.
  if (!processingError && contentType !== "text" && rejectIfTooShort(res, extractedText, language === "en" ? "en" : "he")) {
    return;
  }

  const [material] = await db.insert(materialsTable).values({
    title,
    contentType,
    language,
    courseId,
    sourceUrl,
    userId,
    status,
    extractedText,
    ...(duration ? { duration } : {}),
  }).returning();

  await db.insert(activityTable).values({
    userId,
    activityType: "upload",
    description: `Uploaded "${material.title}"`,
    materialTitle: material.title,
  });

  if (processingError) {
    return res.status(201).json({
      ...await getMaterialWithCounts(material.id, userId),
      extractionWarning: processingError,
    });
  }

  res.status(201).json(await getMaterialWithCounts(material.id, userId));
});

router.get("/materials/:id", async (req, res) => {
  const userId = req.user!.userId;
  const { id } = GetMaterialParams.parse({ id: Number(req.params.id) });
  const material = await getMaterialWithCounts(id, userId);
  if (!material) return res.status(404).json({ error: "Not found" });
  res.json(material);
});

router.delete("/materials/:id", async (req, res) => {
  const userId = req.user!.userId;
  const { id } = DeleteMaterialParams.parse({ id: Number(req.params.id) });
  const [deleted] = await db.delete(materialsTable)
    .where(and(eq(materialsTable.id, id), eq(materialsTable.userId, userId)))
    .returning({ id: materialsTable.id });
  if (!deleted) return res.status(404).json({ error: "Not found" });
  res.status(204).end();
});

export default router;
